package main

import "fmt"

func variables() {
	var quantity int
	quantity = 4
	fmt.Println("Quantity:", quantity)

	var lenght float64 = 1.2
	fmt.Println("Lenght:", lenght)

	var width = 1.8
	fmt.Println("Width:", width)

	index := 10
	fmt.Println("Index:", index)

	bingo := 4
	fmt.Println("Bingo:", bingo)
}
