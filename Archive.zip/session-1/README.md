# Session 1

* Programming Basic Knowhow (Compiler, Interpreter, Syntax, Semantics, IDE, etc.)
* Introduction to Go Language
    * Project setup
    * Main Function
    * Variables
* Data Types
    * Primitive Data Types (int, float64, bool, string)